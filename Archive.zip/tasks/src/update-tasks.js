var updateTaskHandler = function(request) {
    console.log("Update Habit", request)
    return {
        id: "1",
        name: "comer"
    };
}

module.exports = updateTaskHandler;